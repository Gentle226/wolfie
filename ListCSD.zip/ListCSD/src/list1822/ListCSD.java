/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package list1822;

public class ListCSD {

    public static void main(String[] args) {

        MyList1 t = new MyList1();
        Node p, q;
        Person x;
        int k;
        String[] a = {"A", "C", "B", "E", "D"};
        int[] b = {9, 5, 17, 5, 8};

        //(1)
        System.out.println("\n1. Test addLast and addMany");
        t.clear();
        t.addMany(a, b);
        t.traverse();

        //(2)
        System.out.println("\n2. Test searchByName(xName), xName = B");
        t.clear();
        t.addMany(a, b);
        t.traverse();
        p = t.searchByName("B");
        if (p == null) {
            System.out.println("Not found");
        } else {
            System.out.println("The person found is");
            t.visit(p);
            System.out.println();
        }

        //(3)
        System.out.println("\n3. Test addFirst(Person x), x =(X,30)");
        t.clear();
        t.addMany(a, b);
        t.traverse();
        x = new Person("X", 30);
        t.addFirst(x);
        t.traverse();

        //(4)
        System.out.println("\n4. Test insertAfter(q, x), q = (B, 17), x = (X,30)");
        t.clear();
        t.addMany(a, b);
        t.traverse();
        x = new Person("X", 30);
        q = t.searchByName("B");
        t.insertAfter(q, x);
        t.traverse();

        //(5)
        System.out.println("\n5. Test insertBefore(q, x), q = (B, 17), x = (X,30)");
        t.clear();
        t.addMany(a, b);
        t.traverse();
        x = new Person("X", 30);
        q = t.searchByName("B");
        t.insertBefore(q, x);
        t.traverse();

        //(6)
        System.out.println("\n6. Test remove(Node q), q = (B,17)");
        t.clear();
        t.addMany(a, b);
        t.traverse();
        q = t.searchByName("B");
        t.remove(q);
        t.traverse();

        //(7)
        System.out.println("\n Test remove(String xName), xName=B");
        t.clear();
        t.addMany(a, b);
        t.traverse();
        t.remove("B");
        t.traverse();

        //(8)
        System.out.println("\n8. Test remove(int xAge), xAge = 5");
        t.clear();
        t.addMany(a, b);
        t.traverse();
        t.remove(5);
        t.traverse();

        //(9)
        System.out.println("\n8. Test removeAll(int xAge), xAge = 5");
        t.clear();
        t.addMany(a, b);
        t.traverse();
        t.remove(5);
        t.traverse();

        //(10)
        System.out.println("\n10. Test pos(int k), k=2");
        t.clear();
        t.addMany(a, b);
        t.traverse();
        p = t.pos(2);
        System.out.println("The student at position 2 is ");
        t.visit(p);
        System.out.println();

        //(11)
        System.out.println("\n11. Test removePos(int k), k=2");
        t.clear();
        t.addMany(a, b);
        t.traverse();
        t.removePos(2);
        t.traverse();

        //(12)
        System.out.println("\n12. Test sortByName()");
        t.clear();
        t.addMany(a, b);
        t.traverse();
        t.sortByName();
        t.traverse();

        //(13)
        System.out.println("\n13. Test sortByAge()");
        t.clear();
        t.addMany(a, b);
        t.traverse();
        t.sortByAge();
        t.traverse();

        //(14)
        System.out.println("\n14. Test size()");
        t.clear();
        t.addMany(a, b);
        t.traverse();
        k = t.size();
        System.out.println("Size = " + k);

        //(15)
        System.out.println("\n15. Test toArray()");
        t.clear();
        t.addMany(a, b);
        t.traverse();
        Person[] u = t.toArray();
        if (u != null) {
            System.out.println("The array u is: ");
        }

        //(16)
        System.out.println("\n16. Test reverse()");
        t.clear();
        t.addMany(a, b);
        System.out.println("Original list:");
        t.traverse();
        t.reverse();
        System.out.println("Reversed list:");
        t.traverse();

        //(17)
        System.out.println("\n17. Test findMaxAge()");
        t.clear();
        t.addMany(a, b);
        t.traverse();
        Node maxAgeNode = t.findMaxAge();
        if (maxAgeNode != null) {
            System.out.println("The person with the maximum age is:");
            t.visit(maxAgeNode);
        } else {
            System.out.println("No person found (empty list).");
        }

        //(18)
        System.out.println("\n18. Test findMinAge()");
        t.clear();
        t.addMany(a, b);
        t.traverse();
        p = t.findMinAge();
        System.out.println("The student with the minimum age is: ");
        t.visit(p);
        System.out.println();

        //(19)
        System.out.println("\n19. Test setData(): Push new content to node p");
        t.clear();
        t.addMany(a, b);
        t.traverse();
        p = t.searchByName("B");
        x = new Person("XX", 99);
        t.setData(p, x);
        t.traverse();

        String[] c = {"A", "B", "C", "D", "E", "F", "G", "H", "I"};
        int[] d = {9, 8, 7, 6, 15, 4, 3, 2, 1};

        //(20)
        System.out.println("\n20. Test sortByAge(3, 6)");
        t.clear();
        t.addMany(c, d);
        t.traverse();
        t.sortByAge(3, 6);
        t.traverse();

        //(21)
        System.out.println("\n21. Test reverse(3, 6)");
        t.clear();
        t.addMany(c, d);
        t.traverse();
        t.reverse(3, 6);
        t.traverse();
        System.out.println();
    }
} //endddddddddddddddddddddddddddddddddddd :D
