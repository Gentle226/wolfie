/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package list1822;

/**
 *
 * @author MoonWolf
 */
public class Node {
    Person info;
    Node next;
    
    Node(Person x, Node q) {
        info = x;
        next = q;
    }
    
    Node(Person x) {
        this(x, null);
    }
}
